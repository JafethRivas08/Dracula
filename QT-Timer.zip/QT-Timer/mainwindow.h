#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include "ui_mainwindow.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    QTimer *timer;
    int seconds;
    int minutes;
    int hours;
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void count();
    void start();
    void stop();
    void reset();


private:

    Ui::MainWindow *ui;

};

#endif // MAINWINDOW_H

