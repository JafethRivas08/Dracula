#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTimer>
#include <QLCDNumber>



MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    seconds = minutes = hours = 0;
    //Se asigna la libreria QTimer para la funcionalidad de la interfaz
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()),this, SLOT(count())); //QObject::
    // Conecciones a los botones  de Timer Start, Timer Stop y Timer Reset
    this->connect(this->ui->btStart, SIGNAL(clicked()),this, SLOT(start()));
    this->connect(this->ui->btStop, SIGNAL(clicked()),this, SLOT(stop()));
    this->connect(this->ui->btReset, SIGNAL(clicked()),this, SLOT(reset()));

}

void MainWindow::count()
{

 seconds++;
 //condicionales para el formato de los segundos, minutos y horas
 if(seconds == 60){
     minutes++;
     seconds=0;
 }
 if(minutes == 60){
     hours++;
     minutes = 0;
 }
 if(hours == 100){
     hours = 0;
 }
//Conecciones a las subventanas del Temporizador(LCD hh : LCD mm : LCD ss)
this->ui->lcdSeconds->display(seconds);
this->ui->lcdMinutes->display(minutes);
this->ui->lcdHours->display(hours);

}

//Iniciar Tiempo
void MainWindow::start(){

    timer->start(1000);
}
//Detener el tiempo del temporizador
void MainWindow::stop(){

    timer->stop();
}
// reiniciar valores del Temporizador
void MainWindow::reset(){
    seconds = 0;
    minutes = 0;
    hours = 0;
}


MainWindow::~MainWindow()
{
    delete ui;
}


