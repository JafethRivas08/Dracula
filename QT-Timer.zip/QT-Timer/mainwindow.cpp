#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTimer>
#include <QLCDNumber>



MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    seconds = minutes = hours = 0;
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()),this, SLOT(count())); //QObject::
    this->connect(this->ui->btStart, SIGNAL(clicked()),this, SLOT(start()));
    this->connect(this->ui->btStop, SIGNAL(clicked()),this, SLOT(stop()));
    this->connect(this->ui->btReset, SIGNAL(clicked()),this, SLOT(reset()));

}

void MainWindow::count()
{

 seconds++;
 if(seconds == 60){
     minutes++;
     seconds=0;
 }
 if(minutes == 60){
     hours++;
     minutes = 0;
 }
 if(hours == 100){
     hours = 0;
 }

this->ui->lcdSeconds->display(seconds);
this->ui->lcdMinutes->display(minutes);
this->ui->lcdHours->display(hours);

}


void MainWindow::start(){

    timer->start(1000);
}
void MainWindow::stop(){

    timer->stop();
}
void MainWindow::reset(){
    seconds = 0;
    minutes = 0;
    hours = 0;
}


MainWindow::~MainWindow()
{
    delete ui;
}


