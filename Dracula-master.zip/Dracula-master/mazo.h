#ifndef MAZO_H
#define MAZO_H
#include "arraystack.h"
#include "carta.h"

using namespace std;

class Mazo{

private:

public:

    ArrayStack<Carta> mazo;
    Carta newCarta;

    creoMazo(){
        int contador = 0;
        QString paloCarta;

        for(int i = 0; i < 4; i++){
            if(i == 0){
                paloCarta = "corazones";
            }else if(i == 1){
                paloCarta = "espadas";
            }else if(i == 2){
                paloCarta = "flores";
            }else if(i == 3){
                paloCarta = "diamantes";
            }
            for(int j = 1; j < 14; j++){
                newCarta.setNumeroCarta(j);
                newCarta.setTipoCarta(paloCarta);

                mazo.push(newCarta);
            }
        }
    }

};

#endif // MAZO_H
