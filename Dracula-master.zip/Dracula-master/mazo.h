#ifndef MAZO_H
#define MAZO_H
#include "arraylist.h"
#include "carta.h"
#include "arraystack.h"
#include "jugador.h"

using namespace std;

class Mazo{

private:

public:

    ArrayList<Carta> mazo;
    Carta newCarta;

    ArrayStack<Carta> mazoJuego;

    void creoMazo(){
        QString paloCarta;

        for(int i = 0; i < 4; i++){
            if(i == 0){
                paloCarta = "Corazones";
            }else if(i == 1){
                paloCarta = "Espadas";
            }else if(i == 2){
                paloCarta = "Flores";
            }else if(i == 3){
                paloCarta = "Diamantes";
            }
            for(int j = 1; j < 14; j++){
                QString temp = QString::number(j);
                newCarta.setNumeroCarta(temp);
                newCarta.setTipoCarta(paloCarta);

                mazo.append(newCarta);
            }
        }
        newCarta.setNumeroCarta("1");
        newCarta.setTipoCarta("Jockers");

        mazo.append(newCarta);

        newCarta.setNumeroCarta("2");
        newCarta.setTipoCarta("Jockers");

        mazo.append(newCarta);
    }

    void barajarMazo(){
        qsrand(time(NULL));
        for(int i = 0; i < 55; i++){
            mazo.goToPos(qrand()% mazo.getSize());
            mazoJuego.push(mazo.remove());
        }
    }

    QString direcImagen(Carta pCarta){
        QString direccion = ":/" + pCarta.getTipoCarta() + "/" + pCarta.getNumeroCarta() + ".png";
        return direccion;
    }

    Carta darCarta(){
        return mazoJuego.pop();
    }

    QString obtengoGanador(Carta pCartaUno, Carta pCartaDos){
        QString resultado;
        if((pCartaUno.getTipoCarta() == "Corazones" || pCartaUno.getTipoCarta() == "Diamantes") && (pCartaDos.getTipoCarta() == "Flores" ||pCartaUno.getTipoCarta() == "Espadas")){
            resultado = "Jugador 1";

        }else if((pCartaDos.getTipoCarta() == "Corazones" || pCartaDos.getTipoCarta() == "Diamantes") && (pCartaUno.getTipoCarta() == "Flores" ||pCartaUno.getTipoCarta() == "Espadas")){
            resultado = "Jugador 2";

        }else if(pCartaUno.getTipoCarta() == "Corazones" && pCartaDos.getTipoCarta() == "Diamantes"){
            resultado = "Jugador 1";

        }else if(pCartaUno.getTipoCarta() == "Diamantes" && pCartaDos.getTipoCarta() == "Corazones"){
            resultado = "Jugador  2";

        }else if(pCartaUno.getTipoCarta() == "Corazones" && pCartaDos.getTipoCarta() == "Corazones"){
            int temp1 = pCartaUno.getNumeroCarta().toInt();
            int temp2 = pCartaDos.getNumeroCarta().toInt();
            //int temp1 = int::QString(pCartaUno.getNumeroCarta());
            //int temp2 = int::QString(pCartaDos.getNumeroCarta());
            if(temp1 > temp2){
                resultado = "Jugador 1";
            }else if(temp1 < temp2){
                resultado = "Jugador 2";
            }
        }else{
            resultado = "Nadie";
        }
        return resultado;
    }
};

#endif // MAZO_H
