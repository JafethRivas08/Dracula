#ifndef NAIPE_H
#define NAIPE_H
#include "lista.h"
#include "doscartas.h"
#include <QDialog>

namespace Ui {
class naipe;
}

class naipe : public QDialog
{
    Q_OBJECT

public:
    explicit naipe(QWidget *parent = 0);
private:
    ArrayList<int> baraja;
    dosCartas *carta;
    Ui::naipe *ui;
};

#endif // NAIPE_H
