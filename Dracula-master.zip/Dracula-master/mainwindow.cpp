#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "doscartas.h"
#include "instrucciones.h"
#include "QString"
#include "QMessageBox"

QString nombreJ1;
QString nombreJ2;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    instruc = new Instrucciones();
    QObject::connect(dCartas,SIGNAL(backToMain()),this,SLOT(esconder()));
    QObject::connect(instruc,SIGNAL(backToMain()),this,SLOT(esconder()));

    //Insertar imágenes en el botón de salir
    QPixmap pixmap(":/Botones/Salir.png");
    QIcon ButtonIcon(pixmap);
    ui->buttonSalir->setIcon(ButtonIcon);
    ui->buttonSalir->setIconSize(pixmap.rect().size());
    ui->buttonSalir->setFixedSize(pixmap.rect().size());

    //Insertar imágenes en el botón de entrar
    QPixmap pixmap1(":/Botones/FlechaDerecha.png");
    QIcon ButtonIcon1(pixmap1);
    ui->buttonIngresar->setIcon(ButtonIcon1);
    ui->buttonIngresar->setIconSize(pixmap1.rect().size());
    ui->buttonIngresar->setFixedSize(pixmap1.rect().size());
}

void MainWindow::esconder(){
    this->setVisible(true);
    dCartas->setVisible(false);
    instruc->setVisible(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_buttonIngresar_clicked()
{
    if(ui->txtJ1->text().isEmpty() || ui->txtJ1->text().isEmpty()){
        QMessageBox messageBox;
        messageBox.critical(0,"Error","El nombre de los jugadores deben ser ingresados.");
        messageBox.setFixedSize(500,200);
    }else{
        nombreJ1.prepend(ui->txtJ1->text());
        nombreJ2.prepend(ui->txtJ2->text());
        dCartas = new dosCartas(nombreJ1, nombreJ2);
        this->setVisible(false);
        dCartas->setVisible(true);
    }

}

void MainWindow::on_buttonSalir_clicked()
{
    QApplication::quit();
}

void MainWindow::on_btnInstrucciones_clicked()
{
    this->setVisible(false);
    instruc->setVisible(true);
}

QString getNombre1()
{
    return QString(nombreJ1);
}

QString getNombre2()
{
    return nombreJ2;
}
