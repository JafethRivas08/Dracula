#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "doscartas.h"
#include "instrucciones.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    dCartas = new dosCartas();
    instruc = new Instrucciones();
    QObject::connect(dCartas,SIGNAL(backToMain()),this,SLOT(esconder()));
    QObject::connect(instruc,SIGNAL(backToMain()),this,SLOT(esconder()));
}

void MainWindow::esconder(){
    this->setVisible(true);
    dCartas->setVisible(false);
    instruc->setVisible(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_buttonIngresar_clicked()
{
    this->setVisible(false);
    dCartas->setVisible(true);
    //dosCartas dos_cartas;
    //dCartas->setModal(true);
    //dCartas->excec();
}


void MainWindow::on_buttonSalir_clicked()
{
    QApplication::quit();
}

void MainWindow::on_btnInstrucciones_clicked()
{
    this->setVisible(false);
    instruc->setVisible(true);
}
