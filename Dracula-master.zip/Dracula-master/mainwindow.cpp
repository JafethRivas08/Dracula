#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "doscartas.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    dCartas = new dosCartas();
    QObject::connect(dCartas,SIGNAL(backToMain()),this,SLOT(esconder()));
}

void MainWindow::esconder(){
    this->setVisible(true);
    dCartas->setVisible(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_buttonIngresar_clicked()
{
    this->setVisible(false);
    dCartas->setVisible(true);
    //dosCartas dos_cartas;
    //dCartas->setModal(true);
    //dCartas->excec();
}
