#ifndef CARTA_H
#define CARTA_H
#include <QString>

using namespace std;

class Carta{
private:
    QString tipoCarta;
    QString numeroCarta;

public:

    QString getTipoCarta(){
        return tipoCarta;
    }

    void setTipoCarta(QString pTipoCarta){
        tipoCarta = pTipoCarta;
    }

    QString getNumeroCarta(){
        return numeroCarta;
    }

    void setNumeroCarta(QString pNumeroCarta){
        numeroCarta = pNumeroCarta;
    }
};

#endif // CARTA_H
