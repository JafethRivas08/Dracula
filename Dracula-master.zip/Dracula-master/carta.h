#ifndef CARTA_H
#define CARTA_H
#include <QString>

using namespace std;

class Carta{
private:
    QString tipoCarta;
    int numeroCarta;

public:

    QString getTipoCarta(){
        return tipoCarta;
    }

    void setTipoCarta(QString pTipoCarta){
        tipoCarta = pTipoCarta;
    }

    int getNumeroCarta(){
        return numeroCarta;
    }

    void setNumeroCarta(int pNumeroCarta){
        numeroCarta = pNumeroCarta;
    }
};

#endif // CARTA_H
