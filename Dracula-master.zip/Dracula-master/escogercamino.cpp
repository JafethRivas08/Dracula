#include "escogercamino.h"
#include "ui_escogercamino.h"

escogerCamino::escogerCamino(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::escogerCamino)
{
    ui->setupUi(this);
    pJuego = new Juego();
    QObject::connect(pJuego,SIGNAL(back()),this,SLOT(esconder()));
}

void escogerCamino::esconder(){
    this->setVisible(true);
    pJuego->setVisible(false);
}

escogerCamino::~escogerCamino()
{
    delete ui;
}

void escogerCamino::on_back_clicked()
{
    emit(back());
}

void escogerCamino::on_btnJugar_clicked()
{
    this->setVisible(false);
    pJuego->setVisible(true);
}

void escogerCamino::on_cmbEscogerCamino_currentTextChanged(const QString &arg1)
{
    if (arg1 == "Horizontal") {
        ui->txtCamino2->setText("Vertical");
    }else if (arg1 == "Vertical") {
        ui->txtCamino2->setText("Horizontal");
    }
}
