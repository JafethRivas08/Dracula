#include "escogercamino.h"
#include "ui_escogercamino.h"

escogerCamino::escogerCamino(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::escogerCamino)
{
    ui->setupUi(this);
}

escogerCamino::~escogerCamino()
{
    delete ui;
}

void escogerCamino::on_back_clicked()
{
    emit(back());
}
