#include "naipe.h"
#include <cstdlib>

naipe::naipe()
{
    for (int i = 0; i < 55; ++i) {
        baraja.insert(i);
    }
}
int naipe::escogerCarta()
{
    int numRandom = rand() % 54;
    int carta = baraja.getElement(numRandom);
    return carta;
}
