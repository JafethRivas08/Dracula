#include "juego.h"
#include "ui_juego.h"

Juego::Juego(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Juego)
{
    ui->setupUi(this);
}

Juego::~Juego()
{
    delete ui;
}
