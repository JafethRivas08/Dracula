#include "juego.h"
#include "ui_juego.h"
#include <QPixmap>

Juego::Juego(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Juego)
{
    ui->setupUi(this);

    //Insertar imágenes en el botón de home
    QPixmap pixmap(":/Botones/Home.png");
    QIcon ButtonIcon(pixmap);
    ui->backHome->setIcon(ButtonIcon);
    ui->backHome->setIconSize(pixmap.rect().size());
    ui->backHome->setFixedSize(pixmap.rect().size());
}

Juego::~Juego()
{
    delete ui;
}

void Juego::on_backHome_clicked()
{

}
