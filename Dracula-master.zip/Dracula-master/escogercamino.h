#ifndef ESCOGERCAMINO_H
#define ESCOGERCAMINO_H

#include <QDialog>
#include "juego.h"

namespace Ui {
class escogerCamino;
}

class escogerCamino : public QDialog
{
    Q_OBJECT

public:
    explicit escogerCamino(QWidget *parent = 0);
    ~escogerCamino();

signals:
    void back();

private slots:
    void on_back_clicked();
    void on_btnJugar_clicked();
    void esconder();

    void on_cmbEscogerCamino_currentIndexChanged(const QString &arg1);

    void on_cmbEscogerCamino_currentIndexChanged(int index);

    void on_cmbEscogerCamino_currentTextChanged(const QString &arg1);

private:
    Ui::escogerCamino *ui;
    Juego *pJuego;
};

#endif // ESCOGERCAMINO_H
