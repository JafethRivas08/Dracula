#include "doscartas.h"
#include "ui_doscartas.h"
#include "naipe.h"

dosCartas::dosCartas(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::dosCartas)
    {
        ui->setupUi(this);
        direccion = new escogerCamino();
        QObject::connect(direccion,SIGNAL(back()),this,SLOT(esconder()));
    }

void dosCartas::esconder(){
    this->setVisible(true);
    direccion->setVisible(false);
}

dosCartas::~dosCartas()
{
    delete ui;
}

void dosCartas::on_backToMain_clicked()
{
    emit(backToMain());
}

void dosCartas::on_buttonJugar_clicked()
{
    this->setVisible(false);
    direccion->setVisible(true);
}
