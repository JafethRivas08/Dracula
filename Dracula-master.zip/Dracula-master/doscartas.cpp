#include "doscartas.h"
#include "ui_doscartas.h"
#include "naipe.h"
#include <QPixmap>

dosCartas::dosCartas(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::dosCartas)
    {
        ui->setupUi(this);
        direccion = new escogerCamino();
        QObject::connect(direccion,SIGNAL(back()),this,SLOT(esconder()));

        //Insertar imágenes en el botón de entrar
        QPixmap pixmap1(":/Botones/FlechaDerecha.png");
        QIcon ButtonIcon1(pixmap1);
        ui->buttonJugar->setIcon(ButtonIcon1);
        ui->buttonJugar->setIconSize(pixmap1.rect().size());
        ui->buttonJugar->setFixedSize(pixmap1.rect().size());

        //Insertar imágenes en el botón de atras
        QPixmap pixmap(":/Botones/FlechaIzquierda.png");
        QIcon ButtonIcon(pixmap);
        ui->backToMain->setIcon(ButtonIcon);
        ui->backToMain->setIconSize(pixmap.rect().size());
        ui->backToMain->setFixedSize(pixmap.rect().size());
    }

void dosCartas::esconder(){
    this->setVisible(true);
    direccion->setVisible(false);
}

dosCartas::~dosCartas()
{
    delete ui;
}

void dosCartas::on_backToMain_clicked()
{
    emit(backToMain());
}

void dosCartas::on_buttonJugar_clicked()
{
    this->setVisible(false);
    direccion->setVisible(true);
}
