#ifndef DOSCARTAS_H
#define DOSCARTAS_H

#include <QDialog>
#include "escogercamino.h"

namespace Ui {
class dosCartas;
}

class dosCartas : public QDialog
{
    Q_OBJECT

public:
    explicit dosCartas(QString nombreJ1, QString nombreJ2, QWidget *parent = 0);
    ~dosCartas();

signals:
    void backToMain();

private slots:
    void on_backToMain_clicked();
    void on_buttonJugar_clicked();
    void esconder();
    int determinarResultado();
    void on_btnJ1_clicked();

private:
    Ui::dosCartas *ui;
    escogerCamino *direccion;
};

#endif // DOSCARTAS_H
