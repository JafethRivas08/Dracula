#ifndef LISTA_H    // Sección de librerias
#define LISTA_H

#define DEFAULT_MAX_SIZE 1024
#include <stdexcept>
using namespace std;   //Definiendo espacio de trabajo

template <typename E>   // Se declara la plantilla
class ArrayList    // Se define la clase
{
    private:                   // Se declaran las variables
        E *elements;
        int max;
        int size;
        int pos;

    public:
        ArrayList(int pMax = DEFAULT_MAX_SIZE){ // Se definen las variables
            elements = new E[pMax];
            max = pMax;
            size = 0;
            pos = 0;
        }
        virtual ~ArrayList(){       // Destructor
            delete [] elements;
        }

        void insert(E pElement) throw(runtime_error){
            if(size == max){
                throw runtime_error("List is full");
            }
            for (int i = size; i > pos; i--){   //ciclo para insertar
                elements[i] = elements[i-1];
            }
            elements[pos] = pElement;
            size++;
        }

        void append(E pElement) throw(runtime_error){ // manejo de exepciones
            if(size == max){
                throw runtime_error("List is full");
            }
            elements[size] = pElement;
            size++;
        }

        E remove() throw(runtime_error){
            if(size == 0){
                throw runtime_error("List is empty");
            }
            if((pos < 0) || (pos >= size)){
                throw runtime_error("Index out of bounds");
            }

            E temp = elements[pos];

            for (int i = pos; i < size-1; i++){
                elements[i] = elements[i+1];  // Se aumenta el contador en uno
            }
            size--;
            return temp;
        }

        void clear(){
            size = 0;
            pos = 0;
            delete [] elements;
            elements = new E[max];
        }

        E getElement() throw(runtime_error){   // manejo de exepciones
            if(size == 0){
                throw runtime_error("List is empty");
            }
            if(pos > size){
                throw runtime_error("No element");
            }
            return elements[pos];
        }
        // se declaran funciones
        void goToStart(){
            pos = 0;
        }

        void goToEnd(){
            pos = size;
        }

        void goToPos(int pPos) throw(runtime_error){
            if((pPos < 0) || (pPos > size)){   // Condicional para definir la exepción
                throw runtime_error("Index out of bounds");
            }
            pos = pPos;
        }

        void previous(){
            if(pos > 0){
                pos--;
            }
        }

        void next(){
            if(pos < size){
                pos++;
            }
        }

        int getPos(){
            return pos;
        }

        int getSize(){
            return size;
        }



};

#endif // ARRAYLIST_H
