#ifndef ARRAYLIST_H
#define ARRAYLIST_H
#define DEFAULT_MAX_SIZE 54
#include <stdexcept>

using namespace std;
template <typename E>

class ArrayList
{
    private:
        E *elements;
        int max = DEFAULT_MAX_SIZE;
        int size;
        int pos;

    public:
        ArrayList(int pMax = DEFAULT_MAX_SIZE);
        virtual ~ArrayList();
        void insert(E pElement)throw(runtime_error);
        void append(E pElement)throw(runtime_error);
        E remove()throw(runtime_error);
        void clear();
        E getElement() throw(runtime_error);
        void goToStart();
        void goToEnd();
        void goToPos(int pPos)throw(runtime_error);
        void previous();
        void next();
        int getPos(){return pos;}
        int getSize(){return size;}

};

#endif // ARRAYLIST_H
