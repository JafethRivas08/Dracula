#include "arraylist.h"
#include <iostream>

using namespace std;

template <typename E>
ArrayList<E>::ArrayList(int pMax){
    elements = new E[pMax];
    max = pMax;
    size = 0;
    pos = 0;
}

template <typename E>
ArrayList<E>::~ArrayList()
{
    delete [] elements;
}

template <typename E>
void ArrayList<E>::insert(E pElement) throw(runtime_error){
    if(size == max){
        throw runtime_error("List is full");
    }
    for (int i = size; i > pos; i--){
        elements[i] = elements[i-1];
    }
    elements[pos] = pElement;
    size++;
}

template <typename E>
void ArrayList<E>::append(E pElement) throw(runtime_error){
    if(size == max){
        throw runtime_error("List is full");
    }
    elements[size] = pElement;
    size++;
}

template <typename E>
E ArrayList<E>::remove() throw(runtime_error){
    if(size == 0){
        throw runtime_error("List is empty");
    }
    if((pos < 0) || (pos >= size)){
        throw runtime_error("Index out of bounds");
    }

    E temp = elements[pos];

    for (int i = pos; i < size-1; i++){
        elements[i] = elements[i+1];
    }
    size--;
    return temp;
}

template <typename E>
void ArrayList<E>::clear(){
    size = 0;
    pos = 0;
    delete [] elements;
    elements = new E[max];
}

template <typename E>
E ArrayList<E>::getElement() throw(runtime_error){
    if(size == 0){
        throw runtime_error("List is empty");
    }
    if(pos > size){
        throw runtime_error("No element");
    }
    return elements[pos];
}

template <typename E>
void ArrayList<E>::goToStart(){
    pos = 0;
}

template <typename E>
void ArrayList<E>::goToEnd(){
    pos = size;
}

template <typename E>
void ArrayList<E>::goToPos(int pPos) throw(runtime_error){
    if((pPos < 0) || (pPos > size)){
        throw runtime_error("Index out of bounds");
    }
    pos = pPos;
}

template <typename E>
void ArrayList<E>::previous(){
    if(pos > 0){
        pos--;
    }
}

template <typename E>
void ArrayList<E>::next(){
    if(pos < size){
        pos++;
    }
}

