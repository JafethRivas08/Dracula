#include "escogercamino.h"
#include "ui_escogercamino.h"
#include "juego.h"

EscogerCamino::EscogerCamino(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::EscogerCamino)
{
    ui->setupUi(this);

    pJuego = new Juego();
    QObject::connect(pJuego,SIGNAL(back()),this,SLOT(esconder()));

    //Insertar imágenes en el botón de entrar
    QPixmap pixmap1(":/Botones/Check.png");
    QIcon ButtonIcon1(pixmap1);
    ui->btnJugar->setIcon(ButtonIcon1);
    ui->btnJugar->setIconSize(pixmap1.rect().size());
    ui->btnJugar->setFixedSize(pixmap1.rect().size());

    //Insertar imágenes en el botón de atras
    QPixmap pixmap(":/Botones/FlechaIzquierda.png");
    QIcon ButtonIcon(pixmap);
    ui->back->setIcon(ButtonIcon);
    ui->back->setIconSize(pixmap.rect().size());
    ui->back->setFixedSize(pixmap.rect().size());
}

void EscogerCamino::esconder(){
    this->setVisible(true);
    pJuego->setVisible(false);
}

EscogerCamino::~EscogerCamino()
{
    delete ui;
}

void EscogerCamino::on_cmbCamino1_currentTextChanged(const QString &arg1)
{
    if (arg1 == "Horizontal") {
        ui->txtCamino2->setText("Vertical");
    }else if (arg1 == "Vertical") {
        ui->txtCamino2->setText("Horizontal");
    }
}

void EscogerCamino::on_back_clicked()
{
    emit(back());
}

void EscogerCamino::on_btnJugar_clicked()
{
    this->setVisible(false);
    pJuego->setVisible(true);
}
