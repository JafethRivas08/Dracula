#ifndef JUGADORES_H
#define JUGADORES_H
#include "jugador.h"
#include "arraylist.h"


class Jugadores
{
    ArrayList<Jugador> jugadores;
    Jugador newJugador;

public:
    Jugadores();
    ~Jugadores();
    void ingresarJugadores(QString pNombreJugador);
    QString obtengoJugador(int pPos);
};

#endif // JUGADORES_H
