#ifndef ASTACK_H
#define ASTACK_H
#define defaultSize 54
#include <stdexcept>

using namespace std;
template <typename E>

class AStack
{
    private:
        int maxSize;
        int top;
        E *listArray;

    public:
        AStack(int size = defaultSize);

        virtual ~AStack();

        void clear();

        void push(E pElement)throw(runtime_error);

        E pop()throw(runtime_error);

        E topValue()throw(runtime_error);

        int getSize();

};

#endif // ASTACK_H
