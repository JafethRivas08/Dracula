#ifndef ASTACK_H
#define ASTACK_H
#define defaultSize 100
#include <stdexcept>

using namespace std;
template <typename E>

class AStack
{
    private:
        int maxSize;
        int top;
        E *listArray;

    public:
        AStack(int size = defaultSize){
            maxSize = size;
            top = 0;
            listArray = new E[size];
        }
        virtual ~AStack(){
            delete [] listArray;
        }

        void clear(){
            top = 0;
        }

        void push(E pElement)throw(runtime_error){
            if(top == maxSize){
                throw runtime_error("Stack is full");
            }
            listArray[top++] = pElement;
        }

        E pop()throw(runtime_error){
            if(top == 0){
                throw runtime_error("Stack is empty");
            }
            return listArray[--top];
        }

        E topValue()throw(runtime_error){
            if(top == 0){
                throw runtime_error("Stack is empty");
            }
            return listArray[top-1];
        }

        int getSize(){
            return top;
        }

    protected:

};

#endif // ASTACK_H
