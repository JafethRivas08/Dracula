#ifndef JUEGO_H
#define JUEGO_H

#include <QDialog>

namespace Ui {
class Juego;
}

class Juego : public QDialog
{
    Q_OBJECT

public:
    explicit Juego(QWidget *parent = 0);
    ~Juego();

private slots:
    void on_btnEmpezar_clicked();

    void juegoDracula();

    void on_Card1Player1_clicked();

    void on_Card2Player1_clicked();

    void on_Card3Player1_clicked();

    void on_Card4Player1_clicked();

    void on_Card1Player2_clicked();

    void on_Card2Player2_clicked();

    void on_Card3Player2_clicked();

    void on_Card4Player2_clicked();

    void PasarTurno(int movimientoAnterior);

private:
    Ui::Juego *ui;
};

#endif // JUEGO_H
