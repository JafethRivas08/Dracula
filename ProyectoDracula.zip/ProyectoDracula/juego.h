#ifndef JUEGO_H
#define JUEGO_H

#include <QDialog>

namespace Ui {
class Juego;
}

class Juego : public QDialog
{
    Q_OBJECT

public:
    explicit Juego(QWidget *parent = 0);
    ~Juego();

private slots:
    void on_btnInciar_clicked();

private:
    Ui::Juego *ui;
};

#endif // JUEGO_H
