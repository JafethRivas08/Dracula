#include "errorjugadores.h"
#include "ui_errorjugadores.h"

errorJugadores::errorJugadores(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::errorJugadores)
{
    ui->setupUi(this);
}

errorJugadores::~errorJugadores()
{
    delete ui;
}
