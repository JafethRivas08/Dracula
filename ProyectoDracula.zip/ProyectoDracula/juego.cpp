#include "juego.h"
#include "ui_juego.h"
#include "jugadores.h"
#include "carta.h"
#include "mazo.h"
#include "QDebug"

Carta carta1J1;
Carta carta2J1;
Carta carta3J1;
Carta carta4J1;

Carta carta1J2;
Carta carta2J2;
Carta carta3J2;
Carta carta4J2;

Carta cartaCentro;

Mazo mazoJuego;

int ronda = 0;
int movimientos = 0;

Juego::Juego(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Juego)
{
    ui->setupUi(this);

    mazoJuego.barajarMazo();
}

Juego::~Juego()
{
    delete ui;
}

void Juego::on_pos2_2_clicked()
{
    qDebug()<<"prueba";
}

void Juego::on_btnEmpezar_clicked()
{
    ui->btnEmpezar->setEnabled(false);
    juegoDracula();
}

void Juego::juegoDracula(){
    //for(int i = 0; i < 6; i++){
        bool bandera = false;
        if (ronda == 0){
            bandera = true;
        }else if(movimientos == 8){
            bandera = true;
        }
        if(bandera == true){
            ronda ++; // Se aumenta la ronda
            QString r = QString::number(ronda);
            ui->lblRonda->setText("Ronda : " + r);

            cartaCentro = mazoJuego.darCarta();

            carta1J1 = mazoJuego.darCarta();
            carta2J1 = mazoJuego.darCarta();
            carta3J1 = mazoJuego.darCarta();
            carta4J1 = mazoJuego.darCarta();

            carta1J2 = mazoJuego.darCarta();
            carta2J2 = mazoJuego.darCarta();
            carta3J2 = mazoJuego.darCarta();
            carta4J2 = mazoJuego.darCarta();

            QPixmap pixmap(mazoJuego.direcImagen(cartaCentro));
            QIcon ButtonIcon(pixmap);

            QPixmap pixmap1(mazoJuego.direcImagen(carta1J1));
            QIcon ButtonIcon1(pixmap1);
            QPixmap pixmap2(mazoJuego.direcImagen(carta2J1));
            QIcon ButtonIcon2(pixmap2);
            QPixmap pixmap3(mazoJuego.direcImagen(carta3J1));
            QIcon ButtonIcon3(pixmap3);
            QPixmap pixmap4(mazoJuego.direcImagen(carta4J1));
            QIcon ButtonIcon4(pixmap4);

            QPixmap pixmap5(mazoJuego.direcImagen(carta1J2));
            QIcon ButtonIcon5(pixmap5);
            QPixmap pixmap6(mazoJuego.direcImagen(carta2J2));
            QIcon ButtonIcon6(pixmap6);
            QPixmap pixmap7(mazoJuego.direcImagen(carta3J2));
            QIcon ButtonIcon7(pixmap7);
            QPixmap pixmap8(mazoJuego.direcImagen(carta4J2));
            QIcon ButtonIcon8(pixmap8);

            ui->pos2_2->setIcon(ButtonIcon);
            ui->pos2_2->setIconSize(pixmap.rect().size());

            ui->Card1Player1->setIcon(ButtonIcon1);
            ui->Card1Player1->setIconSize(pixmap1.rect().size());
            ui->Card2Player1->setIcon(ButtonIcon2);
            ui->Card2Player1->setIconSize(pixmap2.rect().size());
            ui->Card3Player1->setIcon(ButtonIcon3);
            ui->Card3Player1->setIconSize(pixmap3.rect().size());
            ui->Card4Player1->setIcon(ButtonIcon4);
            ui->Card4Player1->setIconSize(pixmap4.rect().size());


        }
    //}
}

void Juego::on_Card1Player1_clicked()
{

}

void Juego::on_Card2Player1_clicked()
{

}

void Juego::on_Card3Player1_clicked()
{

}

void Juego::on_Card4Player1_clicked()
{

}

void Juego::on_Card1Player2_clicked()
{

}

void Juego::on_Card2Player2_clicked()
{

}

void Juego::on_Card3Player2_clicked()
{

}

void Juego::on_Card4Player2_clicked()
{

}

