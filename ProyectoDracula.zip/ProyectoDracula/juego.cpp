#include "juego.h"
#include "ui_juego.h"
#include "jugadores.h"
#include "carta.h"
#include "mazo.h"
#include "QDebug"
#include <QMessageBox>
#include <QInputDialog>

Carta carta1J1;
Carta carta2J1;
Carta carta3J1;
Carta carta4J1;

Carta carta1J2;
Carta carta2J2;
Carta carta3J2;
Carta carta4J2;

Carta cartaCentro;

Mazo mazoJuego;

int ronda = 0;
int movimientos = 0;

Juego::Juego(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Juego)
{
    ui->setupUi(this);

    mazoJuego.barajarMazo();
}

Juego::~Juego()
{
    delete ui;
}


void Juego::on_btnEmpezar_clicked()
{
    juegoDracula();
    ui->btnEmpezar->setEnabled(false);
}

void Juego::juegoDracula(){
    //for(int i = 0; i < 6; i++){
        bool bandera = false;
        if (ronda == 0){
            bandera = true;
        }else if(movimientos == 8){
            bandera = true;
        }
        if(bandera == true){
            ronda ++; // Se aumenta la ronda
            QString r = QString::number(ronda);
            ui->lblRonda->setText("Ronda : " + r);

            cartaCentro = mazoJuego.darCarta();

            carta1J1 = mazoJuego.darCarta();
            carta2J1 = mazoJuego.darCarta();
            carta3J1 = mazoJuego.darCarta();
            carta4J1 = mazoJuego.darCarta();

            carta1J2 = mazoJuego.darCarta();
            carta2J2 = mazoJuego.darCarta();
            carta3J2 = mazoJuego.darCarta();
            carta4J2 = mazoJuego.darCarta();

            QPixmap pixmap1(mazoJuego.direcImagen(carta1J1));
            QIcon ButtonIcon1(pixmap1);
            QPixmap pixmap2(mazoJuego.direcImagen(carta2J1));
            QIcon ButtonIcon2(pixmap2);
            QPixmap pixmap3(mazoJuego.direcImagen(carta3J1));
            QIcon ButtonIcon3(pixmap3);
            QPixmap pixmap4(mazoJuego.direcImagen(carta4J1));
            QIcon ButtonIcon4(pixmap4);

            QPixmap pixmap5(mazoJuego.direcImagen(carta1J2));
            QIcon ButtonIcon5(pixmap5);
            QPixmap pixmap6(mazoJuego.direcImagen(carta2J2));
            QIcon ButtonIcon6(pixmap6);
            QPixmap pixmap7(mazoJuego.direcImagen(carta3J2));
            QIcon ButtonIcon7(pixmap7);
            QPixmap pixmap8(mazoJuego.direcImagen(carta4J2));
            QIcon ButtonIcon8(pixmap8);

            QPixmap pixmap(mazoJuego.direcImagen(cartaCentro));
            ui->lbl2x2->setPixmap(pixmap);

            ui->Card1Player1->setIcon(ButtonIcon1);
            ui->Card1Player1->setIconSize(pixmap1.rect().size());
            ui->Card2Player1->setIcon(ButtonIcon2);
            ui->Card2Player1->setIconSize(pixmap2.rect().size());
            ui->Card3Player1->setIcon(ButtonIcon3);
            ui->Card3Player1->setIconSize(pixmap3.rect().size());
            ui->Card4Player1->setIcon(ButtonIcon4);
            ui->Card4Player1->setIconSize(pixmap4.rect().size());


        }
    //}
}

void Juego::PasarTurno(int movimientoAnterior){
    if(movimientoAnterior == 1){
        QPixmap pixmap1(":/Otros/CaratulaAzul.png");
        QIcon ButtonIcon1(pixmap1);
        ui->Card1Player1->setIcon(ButtonIcon1);
        ui->Card1Player1->setIconSize(QSize(91,111));
        ui->Card1Player1->setFixedSize(91,111);

        ui->Card2Player1->setIcon(ButtonIcon1);
        ui->Card2Player1->setIconSize(QSize(91,111));
        ui->Card2Player1->setFixedSize(91,111);

        ui->Card3Player1->setIcon(ButtonIcon1);
        ui->Card3Player1->setIconSize(QSize(91,111));
        ui->Card3Player1->setFixedSize(91,111);

        ui->Card4Player1->setIcon(ButtonIcon1);
        ui->Card4Player1->setIconSize(QSize(91,111));
        ui->Card4Player1->setFixedSize(91,111);


        QPixmap pixmap5(mazoJuego.direcImagen(carta1J2));
        QIcon ButtonIcon5(pixmap5);
        QPixmap pixmap6(mazoJuego.direcImagen(carta2J2));
        QIcon ButtonIcon6(pixmap6);
        QPixmap pixmap7(mazoJuego.direcImagen(carta3J2));
        QIcon ButtonIcon7(pixmap7);
        QPixmap pixmap8(mazoJuego.direcImagen(carta4J2));
        QIcon ButtonIcon8(pixmap8);

        ui->Card1Player2->setIcon(ButtonIcon5);
        ui->Card1Player2->setIconSize(QSize(91,111));
        ui->Card1Player2->setFixedSize(91,111);

        ui->Card2Player2->setIcon(ButtonIcon6);
        ui->Card2Player2->setIconSize(QSize(91,111));
        ui->Card2Player2->setFixedSize(91,111);

        ui->Card3Player2->setIcon(ButtonIcon7);
        ui->Card3Player2->setIconSize(QSize(91,111));
        ui->Card3Player2->setFixedSize(91,111);

        ui->Card4Player2->setIcon(ButtonIcon8);
        ui->Card4Player2->setIconSize(QSize(91,111));
        ui->Card4Player2->setFixedSize(91,111);

    }
    if(movimientoAnterior == 2){
        QPixmap pixmap1(":/Otros/CaratulaAzul.png");
        QIcon J(pixmap1);
        ui->Card1Player2->setIcon(J);
        ui->Card1Player2->setIconSize(QSize(91,111));
        ui->Card1Player2->setFixedSize(91,111);

        ui->Card2Player2->setIcon(J);
        ui->Card2Player2->setIconSize(QSize(91,111));
        ui->Card2Player2->setFixedSize(91,111);

        ui->Card3Player2->setIcon(J);
        ui->Card3Player2->setIconSize(QSize(91,111));
        ui->Card3Player2->setFixedSize(91,111);

        ui->Card4Player2->setIcon(J);
        ui->Card4Player2->setIconSize(QSize(91,111));
        ui->Card4Player2->setFixedSize(91,111);


        QPixmap pixmap1(mazoJuego.direcImagen(carta1J1));
        QIcon ButtonIcon1(pixmap1);
        QPixmap pixmap2(mazoJuego.direcImagen(carta2J1));
        QIcon ButtonIcon2(pixmap2);
        QPixmap pixmap3(mazoJuego.direcImagen(carta3J1));
        QIcon ButtonIcon3(pixmap3);
        QPixmap pixmap4(mazoJuego.direcImagen(carta4J1));
        QIcon ButtonIcon4(pixmap4);

        ui->Card1Player1->setIcon(ButtonIcon1);
        ui->Card1Player1->setIconSize(QSize(91,111));
        ui->Card1Player1->setFixedSize(91,111);

        ui->Card2Player1->setIcon(ButtonIcon2);
        ui->Card2Player1->setIconSize(QSize(91,111));
        ui->Card2Player1->setFixedSize(91,111);

        ui->Card3Player1->setIcon(ButtonIcon3);
        ui->Card3Player1->setIconSize(QSize(91,111));
        ui->Card3Player1->setFixedSize(91,111);

        ui->Card4Player1->setIcon(ButtonIcon4);
        ui->Card4Player1->setIconSize(QSize(91,111));
        ui->Card4Player1->setFixedSize(91,111);
    }

}


void Juego::on_Card1Player1_clicked()
{
   QString posicion = QInputDialog::getText(0, "Input dialog", "Ingrese la posición de la carta:", QLineEdit::Normal, "");
   if(posicion == "1x1"){
       if(ui->lbl1x1->isEnabled()){
           QPixmap pixmap(mazoJuego.direcImagen(carta1J1));
           ui->lbl1x1->setPixmap(pixmap);
           ui->lbl1x1->setEnabled(false);
           ui->Card1Player1->setEnabled(false);
           PasarTurno(1);
       }else{
           QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
       }

   }else if(posicion == "1x2"){
       if(ui->lbl1x2->isEnabled()){
           QPixmap pixmap(mazoJuego.direcImagen(carta1J1));
           ui->lbl1x2->setPixmap(pixmap);
           ui->lbl1x2->setEnabled(false);
           ui->Card1Player1->setEnabled(false);
           PasarTurno(1);
       }else{
           QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
       }
   }else if(posicion == "1x3"){
       if(ui->lbl1x3->isEnabled()){
           QPixmap pixmap(mazoJuego.direcImagen(carta1J1));
           ui->lbl1x3->setPixmap(pixmap);
           ui->lbl1x3->setEnabled(false);
           ui->Card1Player1->setEnabled(false);
           PasarTurno(1);
       }else{
           QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
       }
   }else if(posicion == "2x1"){
       if(ui->lbl2x1->isEnabled()){
           QPixmap pixmap(mazoJuego.direcImagen(carta1J1));
           ui->lbl2x1->setPixmap(pixmap);
           ui->lbl2x1->setEnabled(false);
           ui->Card1Player1->setEnabled(false);
           PasarTurno(1);
       }else{
           QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
       }
   }else if(posicion == "2x3"){
       if(ui->lbl2x3->isEnabled()){
           QPixmap pixmap(mazoJuego.direcImagen(carta1J1));
           ui->lbl2x3->setPixmap(pixmap);
           ui->lbl2x3->setEnabled(false);
           ui->Card1Player1->setEnabled(false);
           PasarTurno(1);
       }else{
           QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
       }
   }else if(posicion == "3x1"){
       if(ui->lbl3x1->isEnabled()){
           QPixmap pixmap(mazoJuego.direcImagen(carta1J1));
           ui->lbl3x1->setPixmap(pixmap);
           ui->lbl3x1->setEnabled(false);
           ui->Card1Player1->setEnabled(false);
           PasarTurno(1);
       }else{
           QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
       }
   }else if(posicion == "3x2"){
       if(ui->lbl3x2->isEnabled()){
           QPixmap pixmap(mazoJuego.direcImagen(carta1J1));
           ui->lbl3x2->setPixmap(pixmap);
           ui->lbl3x2->setEnabled(false);
           ui->Card1Player1->setEnabled(false);
           PasarTurno(1);
       }else{
           QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
       }
   }else if(posicion == "3x3"){
       if(ui->lbl3x3->isEnabled()){
           QPixmap pixmap(mazoJuego.direcImagen(carta1J1));
           ui->lbl3x3->setPixmap(pixmap);
           ui->lbl3x3->setEnabled(false);
           ui->Card1Player1->setEnabled(false);
           PasarTurno(1);
       }else{
           QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
       }
   }else{
       QMessageBox::information(this, tr("Error"), tr("Posición inválida") );
   }
}

void Juego::on_Card2Player1_clicked()
{
    QString posicion = QInputDialog::getText(0, "Input dialog", "Ingrese la posición de la carta:", QLineEdit::Normal, "");
    if(posicion == "1x1"){
        if(ui->lbl1x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta2J1));
            ui->lbl1x1->setPixmap(pixmap);
            ui->lbl1x1->setEnabled(false);
            ui->Card2Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }

    }else if(posicion == "1x2"){
        if(ui->lbl1x2->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta2J1));
            ui->lbl1x2->setPixmap(pixmap);
            ui->lbl1x2->setEnabled(false);
            ui->Card2Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "1x3"){
        if(ui->lbl1x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta2J1));
            ui->lbl1x3->setPixmap(pixmap);
            ui->lbl1x3->setEnabled(false);
            ui->Card2Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "2x1"){
        if(ui->lbl2x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta2J1));
            ui->lbl2x1->setPixmap(pixmap);
            ui->lbl2x1->setEnabled(false);
            ui->Card2Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "2x3"){
        if(ui->lbl2x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta2J1));
            ui->lbl2x3->setPixmap(pixmap);
            ui->lbl2x3->setEnabled(false);
            ui->Card2Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x1"){
        if(ui->lbl3x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta2J1));
            ui->lbl3x1->setPixmap(pixmap);
            ui->lbl3x1->setEnabled(false);
            ui->Card2Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x2"){
        if(ui->lbl3x2->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta2J1));
            ui->lbl3x2->setPixmap(pixmap);
            ui->lbl3x2->setEnabled(false);
            ui->Card2Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x3"){
        if(ui->lbl3x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta2J1));
            ui->lbl3x3->setPixmap(pixmap);
            ui->lbl3x3->setEnabled(false);
            ui->Card2Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else{
        QMessageBox::information(this, tr("Error"), tr("Posición inválida") );
    }
}

void Juego::on_Card3Player1_clicked()
{
    QString posicion = QInputDialog::getText(0, "Input dialog", "Ingrese la posición de la carta:", QLineEdit::Normal, "");
    if(posicion == "1x1"){
        if(ui->lbl1x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta3J1));
            ui->lbl1x1->setPixmap(pixmap);
            ui->lbl1x1->setEnabled(false);
            ui->Card3Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }

    }else if(posicion == "1x2"){
        if(ui->lbl1x2->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta3J1));
            ui->lbl1x2->setPixmap(pixmap);
            ui->lbl1x2->setEnabled(false);
            ui->Card3Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "1x3"){
        if(ui->lbl1x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta2J1));
            ui->lbl1x3->setPixmap(pixmap);
            ui->lbl1x3->setEnabled(false);
            ui->Card3Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "2x1"){
        if(ui->lbl2x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta3J1));
            ui->lbl2x1->setPixmap(pixmap);
            ui->lbl2x1->setEnabled(false);
            ui->Card3Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "2x3"){
        if(ui->lbl2x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta3J1));
            ui->lbl2x3->setPixmap(pixmap);
            ui->lbl2x3->setEnabled(false);
            ui->Card3Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x1"){
        if(ui->lbl3x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta3J1));
            ui->lbl3x1->setPixmap(pixmap);
            ui->lbl3x1->setEnabled(false);
            ui->Card3Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x2"){
        if(ui->lbl3x2->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta3J1));
            ui->lbl3x2->setPixmap(pixmap);
            ui->lbl3x2->setEnabled(false);
            ui->Card3Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x3"){
        if(ui->lbl3x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta3J1));
            ui->lbl3x3->setPixmap(pixmap);
            ui->lbl3x3->setEnabled(false);
            ui->Card3Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else{
        QMessageBox::information(this, tr("Error"), tr("Posición inválida") );
    }
}

void Juego::on_Card4Player1_clicked()
{
    QString posicion = QInputDialog::getText(0, "Input dialog", "Ingrese la posición de la carta:", QLineEdit::Normal, "");
    if(posicion == "1x1"){
        if(ui->lbl1x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta4J1));
            ui->lbl1x1->setPixmap(pixmap);
            ui->lbl1x1->setEnabled(false);
            ui->Card4Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }

    }else if(posicion == "1x2"){
        if(ui->lbl1x2->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta4J1));
            ui->lbl1x2->setPixmap(pixmap);
            ui->lbl1x2->setEnabled(false);
            ui->Card4Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "1x3"){
        if(ui->lbl1x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta4J1));
            ui->lbl1x3->setPixmap(pixmap);
            ui->lbl1x3->setEnabled(false);
            ui->Card4Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "2x1"){
        if(ui->lbl2x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta4J1));
            ui->lbl2x1->setPixmap(pixmap);
            ui->lbl2x1->setEnabled(false);
            ui->Card4Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "2x3"){
        if(ui->lbl2x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta4J1));
            ui->lbl2x3->setPixmap(pixmap);
            ui->lbl2x3->setEnabled(false);
            ui->Card4Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x1"){
        if(ui->lbl3x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta4J1));
            ui->lbl3x1->setPixmap(pixmap);
            ui->lbl3x1->setEnabled(false);
            ui->Card4Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x2"){
        if(ui->lbl3x2->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta4J1));
            ui->lbl3x2->setPixmap(pixmap);
            ui->lbl3x2->setEnabled(false);
            ui->Card4Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x3"){
        if(ui->lbl3x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta4J1));
            ui->lbl3x3->setPixmap(pixmap);
            ui->lbl3x3->setEnabled(false);
            ui->Card4Player1->setEnabled(false);
            PasarTurno(1);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else{
        QMessageBox::information(this, tr("Error"), tr("Posición inválida") );
    }
}

void Juego::on_Card1Player2_clicked()
{
    QString posicion = QInputDialog::getText(0, "Input dialog", "Ingrese la posición de la carta:", QLineEdit::Normal, "");
    if(posicion == "1x1"){
        if(ui->lbl1x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta1J2));
            ui->lbl1x1->setPixmap(pixmap);
            ui->lbl1x1->setEnabled(false);
            ui->Card1Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }

    }else if(posicion == "1x2"){
        if(ui->lbl1x2->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta1J2));
            ui->lbl1x2->setPixmap(pixmap);
            ui->lbl1x2->setEnabled(false);
            ui->Card1Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "1x3"){
        if(ui->lbl1x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta1J2));
            ui->lbl1x3->setPixmap(pixmap);
            ui->lbl1x3->setEnabled(false);
            ui->Card1Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "2x1"){
        if(ui->lbl2x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta1J2));
            ui->lbl2x1->setPixmap(pixmap);
            ui->lbl2x1->setEnabled(false);
            ui->Card1Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "2x3"){
        if(ui->lbl2x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta1J2));
            ui->lbl2x3->setPixmap(pixmap);
            ui->lbl2x3->setEnabled(false);
            ui->Card1Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x1"){
        if(ui->lbl3x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta1J2));
            ui->lbl3x1->setPixmap(pixmap);
            ui->lbl3x1->setEnabled(false);
            ui->Card1Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x2"){
        if(ui->lbl3x2->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta1J2));
            ui->lbl3x2->setPixmap(pixmap);
            ui->lbl3x2->setEnabled(false);
            ui->Card1Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x3"){
        if(ui->lbl3x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta1J2));
            ui->lbl3x3->setPixmap(pixmap);
            ui->lbl3x3->setEnabled(false);
            ui->Card1Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else{
        QMessageBox::information(this, tr("Error"), tr("Posición inválida") );
    }
}

void Juego::on_Card2Player2_clicked()
{
    QString posicion = QInputDialog::getText(0, "Input dialog", "Ingrese la posición de la carta:", QLineEdit::Normal, "");
    if(posicion == "1x1"){
        if(ui->lbl1x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta2J2));
            ui->lbl1x1->setPixmap(pixmap);
            ui->lbl1x1->setEnabled(false);
            ui->Card2Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }

    }else if(posicion == "1x2"){
        if(ui->lbl1x2->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta2J2));
            ui->lbl1x2->setPixmap(pixmap);
            ui->lbl1x2->setEnabled(false);
            ui->Card2Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "1x3"){
        if(ui->lbl1x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta2J2));
            ui->lbl1x3->setPixmap(pixmap);
            ui->lbl1x3->setEnabled(false);
            ui->Card2Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "2x1"){
        if(ui->lbl2x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta2J2));
            ui->lbl2x1->setPixmap(pixmap);
            ui->lbl2x1->setEnabled(false);
            ui->Card2Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "2x3"){
        if(ui->lbl2x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta2J2));
            ui->lbl2x3->setPixmap(pixmap);
            ui->lbl2x3->setEnabled(false);
            ui->Card2Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x1"){
        if(ui->lbl3x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta2J2));
            ui->lbl3x1->setPixmap(pixmap);
            ui->lbl3x1->setEnabled(false);
            ui->Card2Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x2"){
        if(ui->lbl3x2->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta2J2));
            ui->lbl3x2->setPixmap(pixmap);
            ui->lbl3x2->setEnabled(false);
            ui->Card2Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x3"){
        if(ui->lbl3x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta2J2));
            ui->lbl3x3->setPixmap(pixmap);
            ui->lbl3x3->setEnabled(false);
            ui->Card2Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else{
        QMessageBox::information(this, tr("Error"), tr("Posición inválida") );
    }
}

void Juego::on_Card3Player2_clicked()
{
    QString posicion = QInputDialog::getText(0, "Input dialog", "Ingrese la posición de la carta:", QLineEdit::Normal, "");
    if(posicion == "1x1"){
        if(ui->lbl1x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta3J2));
            ui->lbl1x1->setPixmap(pixmap);
            ui->lbl1x1->setEnabled(false);
            ui->Card3Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }

    }else if(posicion == "1x2"){
        if(ui->lbl1x2->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta3J2));
            ui->lbl1x2->setPixmap(pixmap);
            ui->lbl1x2->setEnabled(false);
            ui->Card3Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "1x3"){
        if(ui->lbl1x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta3J2));
            ui->lbl1x3->setPixmap(pixmap);
            ui->lbl1x3->setEnabled(false);
            ui->Card3Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "2x1"){
        if(ui->lbl2x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta3J2));
            ui->lbl2x1->setPixmap(pixmap);
            ui->lbl2x1->setEnabled(false);
            ui->Card3Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "2x3"){
        if(ui->lbl2x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta3J2));
            ui->lbl2x3->setPixmap(pixmap);
            ui->lbl2x3->setEnabled(false);
            ui->Card3Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x1"){
        if(ui->lbl3x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta3J2));
            ui->lbl3x1->setPixmap(pixmap);
            ui->lbl3x1->setEnabled(false);
            ui->Card3Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x2"){
        if(ui->lbl3x2->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta3J2));
            ui->lbl3x2->setPixmap(pixmap);
            ui->lbl3x2->setEnabled(false);
            ui->Card3Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x3"){
        if(ui->lbl3x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta3J2));
            ui->lbl3x3->setPixmap(pixmap);
            ui->lbl3x3->setEnabled(false);
            ui->Card3Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else{
        QMessageBox::information(this, tr("Error"), tr("Posición inválida") );
    }
}

void Juego::on_Card4Player2_clicked()
{
    QString posicion = QInputDialog::getText(0, "Input dialog", "Ingrese la posición de la carta:", QLineEdit::Normal, "");
    if(posicion == "1x1"){
        if(ui->lbl1x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta4J2));
            ui->lbl1x1->setPixmap(pixmap);
            ui->lbl1x1->setEnabled(false);
            ui->Card4Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }

    }else if(posicion == "1x2"){
        if(ui->lbl1x2->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta4J2));
            ui->lbl1x2->setPixmap(pixmap);
            ui->lbl1x2->setEnabled(false);
            ui->Card4Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "1x3"){
        if(ui->lbl1x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta4J2));
            ui->lbl1x3->setPixmap(pixmap);
            ui->lbl1x3->setEnabled(false);
            ui->Card4Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "2x1"){
        if(ui->lbl2x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta4J2));
            ui->lbl2x1->setPixmap(pixmap);
            ui->lbl2x1->setEnabled(false);
            ui->Card4Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "2x3"){
        if(ui->lbl2x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta4J2));
            ui->lbl2x3->setPixmap(pixmap);
            ui->lbl2x3->setEnabled(false);
            ui->Card4Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x1"){
        if(ui->lbl3x1->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta4J2));
            ui->lbl3x1->setPixmap(pixmap);
            ui->lbl3x1->setEnabled(false);
            ui->Card4Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x2"){
        if(ui->lbl3x2->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta4J2));
            ui->lbl3x2->setPixmap(pixmap);
            ui->lbl3x2->setEnabled(false);
            ui->Card4Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else if(posicion == "3x3"){
        if(ui->lbl3x3->isEnabled()){
            QPixmap pixmap(mazoJuego.direcImagen(carta4J2));
            ui->lbl3x3->setPixmap(pixmap);
            ui->lbl3x3->setEnabled(false);
            ui->Card4Player2->setEnabled(false);
            PasarTurno(2);
        }else{
            QMessageBox::information(this, tr("Error"), tr("Espacio Utilizado") );
        }
    }else{
        QMessageBox::information(this, tr("Error"), tr("Posición inválida") );
    }
}

