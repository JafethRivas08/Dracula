#include "juego.h"
#include "ui_juego.h"
#include <QPixmap>
#include "jugadores.h"
#include "carta.h"
#include "mazo.h"
#include "QDebug"

Carta carta1J1;
Carta carta2J1;
Carta carta3J1;
Carta carta4J1;

Carta carta1J2;
Carta carta2J2;
Carta carta3J2;
Carta carta4J2;

Mazo mazoJuego;

int ronda = 0;
int movimientos = 0;

Juego::Juego(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Juego)
{
    ui->setupUi(this);

    mazoJuego.barajarMazo();
}

Juego::~Juego()
{
    delete ui;
}

void Juego::on_btnInciar_clicked()
{
    bool bandera = false;
    if (ronda == 0){
        bandera = true;
    }else if(movimientos == 8){
        bandera = true;
    }
    if(bandera == true){
        ronda ++; // Se aumenta la ronda
        QString r = QString::number(ronda);
        ui->lblRonda->setText("Ronda : " + r);
        carta1J1 = mazoJuego.darCarta();
        carta2J1 = mazoJuego.darCarta();
        carta3J1 = mazoJuego.darCarta();
        carta4J1 = mazoJuego.darCarta();

        carta1J2 = mazoJuego.darCarta();
        carta2J2 = mazoJuego.darCarta();
        carta3J2 = mazoJuego.darCarta();
        carta4J2 = mazoJuego.darCarta();

        Carta Carta22; // 2x2 (Carta del centro, 2da fila, 2da columna)

        Carta22 = mazoJuego.darCarta();
        QPixmap Imagen22(mazoJuego.direcImagen(Carta22)); // 2x2 (Carta del centro, 2da fila, 2da columna)

        ui->lblCarta22->setPixmap(Imagen22);

        QPixmap C1J1(mazoJuego.direcImagen(carta1J1));
        QPixmap C2J1(mazoJuego.direcImagen(carta2J1));
        QPixmap C3J1(mazoJuego.direcImagen(carta3J1));
        QPixmap C4J1(mazoJuego.direcImagen(carta4J1));

        ui->lblC1J1->setPixmap(C1J1);
        ui->lblC2J1->setPixmap(C2J1);
        ui->lblC3J1->setPixmap(C3J1);
        ui->lblC4J1->setPixmap(C4J1);
    }
}

