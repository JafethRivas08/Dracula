#include "juego.h"
#include "ui_juego.h"
#include <QPixmap>

Juego::Juego(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Juego)
{
    ui->setupUi(this);
}

Juego::~Juego()
{
    delete ui;
}


//void juegoCompleto(){
  //  for(int i = 0; i < 6; i++){

  //  }
//}
