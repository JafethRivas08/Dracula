#include "instrucciones.h"
#include "ui_instrucciones.h"
#include <QPixmap>

Instrucciones::Instrucciones(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Instrucciones)
{
    ui->setupUi(this);

    //Insertar imágenes en el botón de entrar
    QPixmap pixmap(":/Botones/Check.png");
    QIcon ButtonIcon(pixmap);
    ui->pushButton->setIcon(ButtonIcon);
    ui->pushButton->setIconSize(pixmap.rect().size());
    ui->pushButton->setFixedSize(pixmap.rect().size());
}

Instrucciones::~Instrucciones()
{
    delete ui;
}

void Instrucciones::on_pushButton_clicked()
{
     emit(backToMain());
}
