#include "astack.h"

using namespace std;

template <typename E>
AStack<E>::AStack(int size){
    maxSize = size;
    top = 0;
    listArray = new E[size];
}

template <typename E>
AStack<E>::~AStack(){
    delete [] listArray;
}

template <typename E>
void AStack<E>::clear(){
    top = 0;
}

template <typename E>
void AStack<E>::push(E pElement)throw(runtime_error){
    if(top == maxSize){
        throw runtime_error("Stack is full");
    }
    listArray[top++] = pElement;
}

template <typename E>
E AStack<E>::pop()throw(runtime_error){
    if(top == 0){
        throw runtime_error("Stack is empty");
    }
    return listArray[top--];
}

template <typename E>
E AStack<E>::topValue()throw(runtime_error){
    if(top == 0){
        throw runtime_error("Stack is empty");
    }
    return listArray[top-1];
}

template <typename E>
int AStack<E>::getSize(){
    return top;
}
