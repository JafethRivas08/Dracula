#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "doscartas.h"
#include "instrucciones.h"
#include "jugadores.h"
#include "errorjugadores.h"
#include "juego.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    dCartas = new DosCartas();
    instruc = new Instrucciones();
    error = new errorJugadores();
    QObject::connect(dCartas,SIGNAL(backToMain()),this,SLOT(esconder()));
    QObject::connect(instruc,SIGNAL(backToMain()),this,SLOT(esconder()));


    //Insertar imágenes en el botón de salir
    QPixmap pixmap(":/Botones/Salir.png");
    QIcon ButtonIcon(pixmap);
    ui->btnSalir->setIcon(ButtonIcon);
    ui->btnSalir->setIconSize(pixmap.rect().size());
    ui->btnSalir->setFixedSize(pixmap.rect().size());

    //Insertar imágenes en el botón de entrar
    QPixmap pixmap1(":/Botones/FlechaDerecha.png");
    QIcon ButtonIcon1(pixmap1);
    ui->btnEntrar->setIcon(ButtonIcon1);
    ui->btnEntrar->setIconSize(pixmap1.rect().size());
    ui->btnEntrar->setFixedSize(pixmap1.rect().size());

    //Insertar imágenes en el botón de entrar
    QPixmap pixmap2(":/Botones/Ayuda.png");
    QIcon ButtonIcon2(pixmap2);
    ui->btnInstrucciones->setIcon(ButtonIcon2);
    ui->btnInstrucciones->setIconSize(pixmap1.rect().size());
    ui->btnInstrucciones->setFixedSize(pixmap1.rect().size());
}

void MainWindow::esconder(){
    this->setVisible(true);
    dCartas->setVisible(false);
    instruc->setVisible(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_btnSalir_clicked()
{
    QApplication::quit();
}

void MainWindow::on_btnInstrucciones_clicked()
{
    this->setVisible(false);
    instruc->setVisible(true);
}

void MainWindow::on_btnEntrar_clicked()
{
    if(ui->lineEdit->text() == "" && ui->lineEdit_2->text() == ""){
        error->setVisible(true);
    }else{
        this->setVisible(false);
        dCartas->setVisible(true);

        dCartas->muestroJugadores(ui->lineEdit->text(), ui->lineEdit_2->text());
    }
}





























