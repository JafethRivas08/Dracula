#include "jugador.h"

Jugador::Jugador()
{}

QString Jugador::getNombreJugador(){
    return nombreJugador;
}

void Jugador::setNombreJugador(QString pNombre)
{
    nombreJugador = pNombre;
}
