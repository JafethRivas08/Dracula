#include "timer.h"
#include "ui_juego.h"
#include <QTimer>

Timer::Timer(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Timer)
{

    ui->setupUi(this);
    seconds = minutes = hours = 0;
    //Se asigna la libreria QTimer para la funcionalidad de la interfaz
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()),this, SLOT(count())); //QObject::
    // Conecciones a los botones  de Timer Start, Timer Stop y Timer Reset
    this->connect(this->ui->btStart, SIGNAL(clicked()),this, SLOT(start()));
    //this->connect(this->ui->btStop, SIGNAL(clicked()),this, SLOT(stop()));
    //this->connect(this->ui->btReset, SIGNAL(clicked()),this, SLOT(reset()));

}
