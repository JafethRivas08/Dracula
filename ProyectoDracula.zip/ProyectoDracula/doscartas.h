#ifndef DOSCARTAS_H
#define DOSCARTAS_H

#include <QDialog>
#include "escogercamino.h"
//#include "mainwindow.h"

namespace Ui {
class DosCartas;
}

class DosCartas : public QDialog
{
    Q_OBJECT

signals:
    void backToMain();

public:
    explicit DosCartas(QWidget *parent = 0);
    ~DosCartas();
    void muestroJugadores(QString pJugador1, QString pJugador2);

private slots:
    void on_backToMain_clicked();
    void on_btnJugar_clicked();
    void on_btnRepartir_clicked();
    void esconder();


private:
    Ui::DosCartas *ui;
    EscogerCamino *direccion;
    //MainWindow *ventana;
};

#endif // DOSCARTAS_H
