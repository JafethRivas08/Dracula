#ifndef DOSCARTAS_H
#define DOSCARTAS_H

#include <QDialog>
#include "escogercamino.h"

namespace Ui {
class DosCartas;
}

class DosCartas : public QDialog
{
    Q_OBJECT

signals:
    void backToMain();

public:
    explicit DosCartas(QString nombreJ1, QString nombreJ2, QWidget *parent = 0);
    ~DosCartas();

private slots:
    void on_backToMain_clicked();
    void on_btnJugar_clicked();
    void on_btnRepartir_clicked();
    void esconder();

private:
    Ui::DosCartas *ui;
    EscogerCamino *direccion;
    QString J1;
    QString J2;
};

#endif // DOSCARTAS_H
