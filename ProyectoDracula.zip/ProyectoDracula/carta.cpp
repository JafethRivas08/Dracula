#include "carta.h"
#include <QString>

Carta::Carta()
{}

QString Carta::getTipoCarta(){
    return tipoCarta;
}

void Carta::setTipoCarta(QString pTipoCarta){
    tipoCarta = pTipoCarta;
}

QString Carta::getNumeroCarta(){
    return numeroCarta;
}

void Carta::setNumeroCarta(QString pNumeroCarta){
    numeroCarta = pNumeroCarta;
}
