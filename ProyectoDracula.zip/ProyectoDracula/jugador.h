#ifndef JUGADOR_H
#define JUGADOR_H
#include <QString>


class Jugador
{
private:
    QString nombreJugador;
    //bool escojoCamino;

public:
    Jugador();
    QString getNombreJugador();
    void setNombreJugador(QString pNombre);

};

#endif // JUGADOR_H
