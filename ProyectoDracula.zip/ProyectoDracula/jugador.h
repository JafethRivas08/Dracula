#ifndef JUGADOR_H
#define JUGADOR_H

class jugador
{
public:
    jugador();
};

#endif // JUGADOR_H
