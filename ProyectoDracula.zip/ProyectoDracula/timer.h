#ifndef TIMER_H
#define TIMER_H

#include <QObject>
#include <QWidget>

class Timer : public QWidget
{
    Q_OBJECT
public:
    explicit Timer(QWidget *parent = 0);

signals:

public slots:
};

#endif // TIMER_H