#ifndef MAZO_H
#define MAZO_H
#include "arraylist.h"
#include "carta.h"
#include "astack.h"
//#include "jugador.h"
#include <QDebug>


class Mazo{



public:
    ArrayList<Carta> mazo;
    Carta newCarta;

    AStack<Carta> mazoJuego;

    void creoMazo();

    void barajarMazo();

    QString direcImagen(Carta pCarta);

    Carta darCarta();

    QString obtengoGanador(Carta pCartaUno, Carta pCartaDos);

};

#endif // MAZO_H
