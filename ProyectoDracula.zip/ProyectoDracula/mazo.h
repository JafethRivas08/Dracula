#ifndef MAZO_H
#define MAZO_H
#include "arraylist.h"
#include "carta.h"
#include "astack.h"
//#include "jugador.h"
#include <QDebug>

using namespace std;



class Mazo{
    Carta newCarta;
    ArrayList<Carta> mazo;

    AStack<Carta> mazoJuego;


public:


    Mazo();

    ~Mazo();

    void barajarMazo();

    Carta darCarta();

    QString direcImagen(Carta pCarta);

    QString obtengoGanador(Carta pCartaUno, Carta pCartaDos);

};

#endif // MAZO_H
