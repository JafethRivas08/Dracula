#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "doscartas.h"
#include "instrucciones.h"
#include "QString"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    QString getnombre1();
    QString getnombre2();
    ~MainWindow();

private slots:
    void on_btnSalir_clicked();
    void esconder();
    void on_btnInstrucciones_clicked();
    void on_btnEntrar_clicked();

private:
    Ui::MainWindow *ui;
    DosCartas *dCartas;
    Instrucciones *instruc;
};

#endif // MAINWINDOW_H
