#ifndef ERRORJUGADORES_H
#define ERRORJUGADORES_H

#include <QDialog>

namespace Ui {
class errorJugadores;
}

class errorJugadores : public QDialog
{
    Q_OBJECT

public:
    explicit errorJugadores(QWidget *parent = 0);
    ~errorJugadores();

private:
    Ui::errorJugadores *ui;
};

#endif // ERRORJUGADORES_H
