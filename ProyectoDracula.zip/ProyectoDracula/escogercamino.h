#ifndef ESCOGERCAMINO_H
#define ESCOGERCAMINO_H

#include <QDialog>
#include "juego.h"

namespace Ui {
class EscogerCamino;
}

class EscogerCamino : public QDialog
{
    Q_OBJECT

public:
    explicit EscogerCamino(QWidget *parent = 0);
    ~EscogerCamino();

signals:
    void back();

private slots:
    //void on_cmbCamino1_currentIndexChanged(const QString &arg1);
    //void on_cmbCamino1_currentIndexChanged(int index);
    void on_cmbCamino1_currentTextChanged(const QString &arg1);
    //void on_cmbCamino1_activated(const QString &arg1);

    void on_back_clicked();
    void on_btnJugar_clicked();
    void esconder();


private:
    Ui::EscogerCamino *ui;
    Juego *pJuego;
};

#endif // ESCOGERCAMINO_H
