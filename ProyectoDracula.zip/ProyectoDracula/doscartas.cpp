#include "doscartas.h"
#include "ui_doscartas.h"
#include <QPixmap>
#include "mazo.h"
#include "carta.h"
#include <QDebug>
#include "escogercamino.h"
#include "jugadores.h"
#include "mainwindow.h"

DosCartas::DosCartas(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DosCartas)
{
    ui->setupUi(this);
    //ventana = new MainWindow;

    direccion = new EscogerCamino();
    QObject::connect(direccion,SIGNAL(back()),this,SLOT(esconder()));

    //Insertar imágenes en el botón de entrar
    QPixmap pixmap1(":/Botones/FlechaDerecha.png");
    QIcon ButtonIcon1(pixmap1);
    ui->btnJugar->setIcon(ButtonIcon1);
    ui->btnJugar->setIconSize(pixmap1.rect().size());
    ui->btnJugar->setFixedSize(pixmap1.rect().size());

    //Insertar imágenes en el botón de atras
    QPixmap pixmap(":/Botones/FlechaIzquierda.png");
    QIcon ButtonIcon(pixmap);
    ui->backToMain->setIcon(ButtonIcon);
    ui->backToMain->setIconSize(pixmap.rect().size());
    ui->backToMain->setFixedSize(pixmap.rect().size());

    //Poner los nombres de los jugadores
    //Jugadores jugador;
    //ui->Jugador1->setText(jugador.obtengoJugador(0));
    //ui->Jugador1->setText(jugador.obtengoJugador(1));

    if(ui->btnRepartir->text() == "Repartir"){
        ui->btnJugar->setEnabled(false);
    }
}

void DosCartas::muestroJugadores(QString pJugador1, QString pJugador2){
    ui->Jugador1->setText(pJugador1);
    ui->Jugador2->setText(pJugador2);
}

void DosCartas::esconder(){
    this->setVisible(true);
    direccion->setVisible(false);
}

DosCartas::~DosCartas()
{
    delete ui;
}

void DosCartas::on_backToMain_clicked()
{
}

void DosCartas::on_btnJugar_clicked()
{
    this->setVisible(false);
    direccion->setVisible(true);

}

void DosCartas::on_btnRepartir_clicked()
{
    if(ui->btnRepartir->text() == "Repartir"){
        ui->btnJugar->setEnabled(false);
        Carta cartaUno;
        Carta cartaDos;

        Mazo mazoJuego;

        mazoJuego.barajarMazo();

        cartaUno = mazoJuego.darCarta();
        //qDebug()<<mazoJuego.darCarta().getNumeroCarta();
        //qDebug()<<mazoJuego.darCarta().getTipoCarta();
        cartaDos = mazoJuego.darCarta();

        //qDebug()<<mazoJuego.direcImagen(cartaUno);


        QPixmap ImagenUno(mazoJuego.direcImagen(cartaUno));
        //qDebug()<<mazoJuego.direcImagen(cartaUno);
        QPixmap ImagenDos(mazoJuego.direcImagen(cartaDos));
        //qDebug()<<mazoJuego.direcImagen(cartaDos);

        ui->carta1->setPixmap(ImagenUno);
        ui->carta2->setPixmap(ImagenDos);

        if(mazoJuego.obtengoGanador(cartaUno, cartaDos) == "Jugador 1"){
            ui->btnRepartir->setText("Continuar");
            ui->btnRepartir->setEnabled(false);
            ui->btnJugar->setEnabled(true);
            ui->label->setText("GANADOR");

        }else if(mazoJuego.obtengoGanador(cartaUno, cartaDos) == "Jugador 2"){
            ui->btnRepartir->setText("Continuar");
            ui->btnRepartir->setEnabled(false);
            ui->btnJugar->setEnabled(true);
            ui->label_2->setText("GANADOR");
        }
    }
}
