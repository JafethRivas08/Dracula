#ifndef INSTRUCCIONES_H
#define INSTRUCCIONES_H

#include <QDialog>

namespace Ui {
class Instrucciones;
}

class Instrucciones : public QDialog
{
    Q_OBJECT

public:
    explicit Instrucciones(QWidget *parent = 0);
    ~Instrucciones();

signals:
    void backToMain();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Instrucciones *ui;
};

#endif // INSTRUCCIONES_H
