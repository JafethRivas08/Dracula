#include "jugadores.h"

Jugadores::Jugadores()
{
}

Jugadores::~Jugadores(){
    jugadores.~ArrayList();
}

void Jugadores::ingresarJugadores(QString pNombreJugador){

    newJugador.setNombreJugador(pNombreJugador);

    jugadores.append(newJugador);
}

QString Jugadores::obtengoJugador(int pPos){
    jugadores.goToPos(pPos);
    return jugadores.getElement().getNombreJugador();
}
