#ifndef CARTA_H
#define CARTA_H
#include <QString>


class Carta
{
private:
    QString tipoCarta;
    QString numeroCarta;

public:
    Carta();
    QString getTipoCarta();
    void setTipoCarta(QString pTipoCarta);
    QString getNumeroCarta();
    void setNumeroCarta(QString pNumeroCarta);
};

#endif // CARTA_H
